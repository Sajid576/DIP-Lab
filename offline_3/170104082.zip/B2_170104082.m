% implement Gaussian filtering from scratch

clc;    % Clear the command window.
close all;  % Close all figures (except those of imtool.)
imtool close all;  % Close all imtool figures if you have the Image Processing Toolbox.
clear;  % Erase all existing variables. Or clearvars if you want.


sigma = input('Enter the value of sigma: ');
image = imread('funny_pic.jpg');
kernel_size = 7;  %for 7*7 kernel size

% rgb to gray 
image_gray = rgb2gray(image);
[row,col] = size(image_gray);
a = floor(kernel_size/2); 

% Input Image
figure;
subplot(1,2,1);
imshow(rgb2gray(image));
title('Input image');

% new image with zero padding
image_padded = zeros(row + 2*a, col + 2*a,'uint8'); 
image_padded(3:row+2,3:col+2) = image_gray(:,:);
lel=image_padded;
image_padded = im2double(image_padded);



% Preparing Gaussian Kernel
gauss_matrix = zeros(kernel_size,kernel_size);
c = 1 /(2*pi*sigma^2);
for x = -a:a
    for y = -a:a
        t1= -(x^2 + y^2);
        t2= (2 * sigma^2);
        e = exp(t1 / t2);
        gauss_matrix(x+a+1,y+a+1) = c * e;
    end
end

% Applying Gaussian Filter
[row,col] = size(image_padded);
for i = a+1:row-a
   for j = a+1:col-a
       t3 = image_padded(i-a : i+a, j-a : j+a);
       t4 = gauss_matrix .* t3;
       t4 = sum(t4(:));
       image_padded(i,j) = t4;
   end
end
[row,col] = size(image_padded);
output = image_padded(a+1:row-a,a+1:col-a);

% for output
subplot(1,2,2);
imshow(output); 
title('Output Image');










